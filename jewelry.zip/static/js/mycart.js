var updateBtns = document.getElementsByClassName('update-cart')

for (i = 0; i < updateBtns.length; i++) {
	updateBtns[i].addEventListener('click', function(){
		var jewId = this.dataset.jewl
		var action = this.dataset.action
		console.log('jewId:', jewId, 'Action:', action)
		console.log('USER:', user)

        if (user == 'AnonymousUser'){
			console.log("login to cart")
			addCookieItem(jewId, action)

		}else{
		    // logged in user
			updateUserOrder(jewId, action)
		}
	})
}

function updateUserOrder(jewId, action){
	console.log('User is authenticated, sending data...')

	var url = '/updateitem/'

	fetch(url, {
		method:'POST',
		headers:{
			'Content-Type':'application/json',
			'X-CSRFToken':csrftoken,
		},
		body:JSON.stringify({'jewId':jewId, 'action':action})
	})
	.then((response) => {
		  return response.json();
	})
	.then((data) => {
		  location.reload()
	});
}

function addCookieItem(jewId, action){
	console.log('User is not authenticated')

	if (action == 'add'){
		if (cart[jewId] == undefined){
		cart[jewId] = {'quantity':1}

		}else{
			cart[jewId]['quantity'] += 1
		}
	}

	if (action == 'remove'){
		cart[jewId]['quantity'] -= 1

		if (cart[jewId]['quantity'] <= 0){
			console.log('Item should be deleted')
			delete cart[jewId];
		}
	}
	console.log('CART:', cart)
	document.cookie ='cart=' + JSON.stringify(cart) + ";domain=;path=/"

	location.reload()
}
