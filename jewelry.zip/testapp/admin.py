from django.contrib import admin
from testapp.models import Jewl,Customer,OrderItem,Order,ContactUs
# Register your models here.
class Jewladmin(admin.ModelAdmin):
    list_display = ['jewId', 'jewName', 'jewcategory', 'jewDescription', 'jewPrice', 'jewImage']


admin.site.register(Jewl, Jewladmin)
admin.site.register(Customer)
admin.site.register(Order)
admin.site.register(OrderItem)
admin.site.register(ContactUs)

