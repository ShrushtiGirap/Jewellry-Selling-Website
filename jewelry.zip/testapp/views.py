from django.shortcuts import render, redirect
from testapp.models import Jewl,Customer, User, Order,OrderItem, ContactUs
from testapp.forms import JewlForm, CustomerForm,CreateUserForm, ContactusForm
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.http import JsonResponse
from testapp.utils import cartData,cookieCart
from django.contrib.auth.models import Group
import json

def index_view(request):
    return render(request,'testapp/index.html')

def home_view(request):
    return render(request,'testapp/home.html')

def jewels_view(request):
    jewl=Jewl.objects.all()
    return render(request,'testapp/jewels.html',{'jewl':jewl})

def aboutus_view(request):
    return render(request,'testapp/aboutus.html')

def jewellrylist_view(request):
    jewl = Jewl.objects.all()
    return render(request, 'testapp/jewellrylist.html', {'jewl': jewl})

def addjewellry_view(request):
    if request.method=='POST':
        form=JewlForm(data=request.POST,files=request.FILES)
        if form.is_valid():
            form.save()

            return redirect('/jewellrylist')
    else:
        form = JewlForm()
    return render(request,'testapp/addjewellry.html',{'form':form})

def deletejewl(request,jewId):
    jewl=Jewl.objects.get(jewId=jewId)
    jewl.delete()
    return redirect('/jewellrylist')

def updatejewellry_view(request,jewId):
    jewl=Jewl.objects.get(jewId=jewId)
    if request.method=='POST':
        form=JewlForm(data=request.POST,files=request.FILES,instance=jewl)
        if form.is_valid():
            form.save()
            return redirect('/jewellrylist')
    else:
        form=JewlForm(instance=jewl)
    return render(request,'testapp/updatejewellry.html',{'form':form})

def customerlist_view(request):
    customer=Customer.objects.all()
    return render(request,'testapp/customerlist.html',{'customer':customer})

def signup_view(request):
    if request.user.is_authenticated:
        return redirect('/home')
    else:
        form = CreateUserForm()
        if request.method=='POST':
            form=CreateUserForm(request.POST)
            if form.is_valid():
                user=form.save()
                username = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + username)
                return redirect('/login')

           # { % if request.user.is_staff %}

    return render(request,'accounts/signup.html',{'form':form})

def login_view(request):
    if request.user.is_authenticated:
        return  redirect('/home')
    else:
        if request.method=='POST':
            username=request.POST.get('username')
            password = request.POST.get('password')
            user=authenticate(request,username=username,password=password)
            if user is not None:
                login(request, user)
                return redirect('/customerdetail')
            else:
                messages.info(request, 'Username OR password is incorrect')

    return render(request, 'accounts/login.html')

def customerdetail_view(request):
    user = request.user
    if request.method == 'POST':
        form = CustomerForm(data=request.POST, files=request.FILES)
        if form.is_valid():
            form.save()
        return redirect('/profile')
    else:
        form = CustomerForm()

    return render(request, 'accounts/customerdetails.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('/login')


def cart(request):
    data = cartData(request)

    cartItems = data['cartItems']
    order = data['order']
    items = data['items']

    context = {'items': items, 'order': order, 'cartItems': cartItems}
    return render(request, 'testapp/mycart.html',context)


def updateItem(request):
    data = json.loads(request.body,encoding='utf-8')
    jewId = data['jewId']
    action = data['action']
    print('Action:', action)
    print('jewId:', jewId)

    customer = request.user.customer
    jewl = Jewl.objects.get(jewId=jewId)
    order, created = Order.objects.get_or_create(customer=customer, complete=False)

    orderItem, created = OrderItem.objects.get_or_create(order=order, jewl=jewl)

    if action == 'add':
        orderItem.quantity = (orderItem.quantity + 1)
    elif action == 'remove':
        orderItem.quantity = (orderItem.quantity - 1)

    orderItem.save()


    if orderItem.quantity <= 0:
        orderItem.delete()

    return JsonResponse('Item was added', safe=False)


def profile_view(request):
    user=request.user
    customer=Customer.objects.filter(user=user)
    return render(request,'accounts/profile.html',{'customer':customer})

def profileupdate(request):
    context={}
    customer=Customer.objects.get(user__id=request.user.id)
    context['customer']=customer
    if request.method == 'POST':
        name=request.POST['name']
        email=request.POST['email']
        phone=request.POST['phone']
        address=request.POST['address']
        user=User.objects.get(id=request.user.id)
        user.email=email
        user.save()
        customer.name=name
        customer.phone=phone
        customer.address=address
        customer.save()
        if "image" in request.FILES:
            img=request.FILES['image']
            customer.profilepic=img
            customer.save()

    return render(request,'accounts/profileupdate.html',context)



def contactus_view(request):
    if request.method == 'POST':
        form =ContactusForm(data=request.POST, files=request.FILES)
        if form.is_valid():
            form.save()
            return redirect('/home')
    else:
        form = ContactusForm()
    return render(request, 'testapp/contactus.html', {'form': form})

def contactquery(request):
    contactquery=ContactUs.objects.all()
    return render(request,'testapp/contactquery.html',{'contactquery':contactquery})

def orderlist(request):
    order=OrderItem.objects.all()
    return render(request, 'testapp/orderlist.html', {'order': order})

